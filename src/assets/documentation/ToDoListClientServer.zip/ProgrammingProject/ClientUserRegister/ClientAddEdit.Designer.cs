﻿using System.DirectoryServices;

namespace ClientUserRegister
{
    partial class ClientAddEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            taskNameBox = new TextBox();
            taskDescriptionBox = new TextBox();
            dueDateBox = new TextBox();
            priorityOptionsBox = new ComboBox();
            userIDBox = new TextBox();
            okButton = new Button();
            cancelButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(36, 105);
            label1.Name = "label1";
            label1.Size = new Size(85, 21);
            label1.TabIndex = 0;
            label1.Text = "Task Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(36, 156);
            label2.Name = "label2";
            label2.Size = new Size(122, 21);
            label2.TabIndex = 1;
            label2.Text = "Task Description";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(36, 258);
            label3.Name = "label3";
            label3.Size = new Size(74, 21);
            label3.TabIndex = 2;
            label3.Text = "Due Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(36, 318);
            label4.Name = "label4";
            label4.Size = new Size(61, 21);
            label4.TabIndex = 3;
            label4.Text = "Priority";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(36, 379);
            label5.Name = "label5";
            label5.Size = new Size(61, 21);
            label5.TabIndex = 4;
            label5.Text = "User ID";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 16F);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(36, 44);
            label6.Name = "label6";
            label6.Size = new Size(110, 30);
            label6.TabIndex = 5;
            label6.Text = "ADD/EDIT";
            // 
            // taskNameBox
            // 
            taskNameBox.Font = new Font("Segoe UI", 12F);
            taskNameBox.Location = new Point(228, 105);
            taskNameBox.Name = "taskNameBox";
            taskNameBox.PlaceholderText = "e.g. Water Plants";
            taskNameBox.Size = new Size(406, 29);
            taskNameBox.TabIndex = 6;
            // 
            // taskDescriptionBox
            // 
            taskDescriptionBox.Font = new Font("Segoe UI", 12F);
            taskDescriptionBox.Location = new Point(228, 156);
            taskDescriptionBox.Multiline = true;
            taskDescriptionBox.Name = "taskDescriptionBox";
            taskDescriptionBox.PlaceholderText = "Brief description of task";
            taskDescriptionBox.Size = new Size(406, 76);
            taskDescriptionBox.TabIndex = 7;
            // 
            // dueDateBox
            // 
            dueDateBox.Font = new Font("Segoe UI", 12F);
            dueDateBox.Location = new Point(228, 258);
            dueDateBox.Name = "dueDateBox";
            dueDateBox.PlaceholderText = "dd-mm-yyyy";
            dueDateBox.Size = new Size(170, 29);
            dueDateBox.TabIndex = 8;
            // 
            // priorityOptionsBox
            // 
            priorityOptionsBox.Font = new Font("Segoe UI", 12F);
            priorityOptionsBox.FormattingEnabled = true;
            priorityOptionsBox.Items.AddRange(new object[] { "Low", "Normal", "High" });
            priorityOptionsBox.Location = new Point(228, 318);
            priorityOptionsBox.Name = "priorityOptionsBox";
            priorityOptionsBox.Size = new Size(170, 29);
            priorityOptionsBox.TabIndex = 9;
            // 
            // userIDBox
            // 
            userIDBox.Font = new Font("Segoe UI", 12F);
            userIDBox.Location = new Point(228, 379);
            userIDBox.Name = "userIDBox";
            userIDBox.Size = new Size(170, 29);
            userIDBox.TabIndex = 10;
            // 
            // okButton
            // 
            okButton.Font = new Font("Segoe UI", 12F);
            okButton.Location = new Point(548, 459);
            okButton.Name = "okButton";
            okButton.Size = new Size(86, 40);
            okButton.TabIndex = 11;
            okButton.Text = "OK";
            okButton.UseVisualStyleBackColor = true;
            okButton.Click += okButton_Click;
            // 
            // cancelButton
            // 
            cancelButton.Font = new Font("Segoe UI", 12F);
            cancelButton.Location = new Point(36, 459);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(122, 40);
            cancelButton.TabIndex = 12;
            cancelButton.Text = "CANCEL";
            cancelButton.UseVisualStyleBackColor = true;
            cancelButton.Click += cancelButton_Click;
            // 
            // ClientAddEdit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(204, 221, 255);
            ClientSize = new Size(671, 538);
            Controls.Add(cancelButton);
            Controls.Add(okButton);
            Controls.Add(userIDBox);
            Controls.Add(priorityOptionsBox);
            Controls.Add(dueDateBox);
            Controls.Add(taskDescriptionBox);
            Controls.Add(taskNameBox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ClientAddEdit";
            Text = "ClientAddEdit";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox taskNameBox;
        private TextBox taskDescriptionBox;
        private TextBox dueDateBox;
        private ComboBox priorityOptionsBox;
        private TextBox userIDBox;
        private Button okButton;
        private Button cancelButton;
    }
}