﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text.Json;
using System.Windows.Forms;
using DTOLibrary;

namespace ClientUserRegister
{
    public partial class ClientMainForm : Form
    {
        private TcpClient client;
        private BinaryReader br;
        private BinaryWriter bw;
        private int userId;

        public ClientMainForm(TcpClient client, BinaryReader br, BinaryWriter bw, int userId)
        {
            InitializeComponent();
            this.client = client;
            this.br = br;
            this.bw = bw;
            this.userId = userId;
            LoadTasks();

            taskListView.DoubleClick += TaskListView_DoubleClick;
        }

        private void ClientMainForm_Load(object sender, EventArgs e)
        {
            taskListView.Columns.Add("Task ID", 75);
            taskListView.Columns.Add("Task Name", 150);
            taskListView.Columns.Add("Description", 300);
            taskListView.Columns.Add("Due Date", 75);
            taskListView.Columns.Add("Priority", 75);
            taskListView.Columns.Add("User ID", 75);
        }

        private void TaskListView_DoubleClick(object sender, EventArgs e)
        {
            if (taskListView.SelectedItems.Count == 0)
            {
                return;
            }

            ListViewItem selectedItem = taskListView.SelectedItems[0];
            ToDoItemDTO task = new ToDoItemDTO
            {
                TaskID = int.Parse(selectedItem.SubItems[0].Text),
                TaskName = selectedItem.SubItems[1].Text,
                Description = selectedItem.SubItems[2].Text,
                DueDate = selectedItem.SubItems[3].Text,
                Priority = selectedItem.SubItems[4].Text,
                UserID = int.Parse(selectedItem.SubItems[5].Text)
            };

            ClientAddEdit addEditForm = new ClientAddEdit(br, bw, task);
            addEditForm.ShowDialog();
            LoadTasks();
        }

        private void LoadTasks()
        {
            taskListView.Items.Clear();

            RequestDTO request = new RequestDTO { Action = "GetTasks" };
            string requestJson = JsonSerializer.Serialize(request);
            bw.Write(requestJson);
            bw.Flush();

            string responseJson = br.ReadString();
            ResponseDTO response = JsonSerializer.Deserialize<ResponseDTO>(responseJson);
            if (response.Success)
            {
                List<ToDoItemDTO> tasks = JsonSerializer.Deserialize<List<ToDoItemDTO>>(response.Data.ToString());
                foreach (var item in tasks)
                {
                    var listViewItem = new ListViewItem(item.TaskID.ToString());
                    listViewItem.SubItems.Add(item.TaskName);
                    listViewItem.SubItems.Add(item.Description);
                    listViewItem.SubItems.Add(item.DueDate);
                    listViewItem.SubItems.Add(item.Priority);
                    listViewItem.SubItems.Add(item.UserID.ToString());
                    taskListView.Items.Add(listViewItem);
                }
            }
            else
            {
                MessageBox.Show("Was unable to show tasks");
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            ClientAddEdit addEditForm = new ClientAddEdit(br, bw, userId);
            addEditForm.ShowDialog();
            LoadTasks();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (taskListView.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select an item to delete first!");
                return;
            }

            int taskId = int.Parse(taskListView.SelectedItems[0].Text);
            RequestDTO request = new RequestDTO { Action = "DeleteTask", Data = taskId };
            string requestJson = JsonSerializer.Serialize(request);
            bw.Write(requestJson);
            bw.Flush();
            string responseJson = br.ReadString();
            ResponseDTO response = JsonSerializer.Deserialize<ResponseDTO>(responseJson);

            if (response.Success)
            {
                LoadTasks();
            }
            else
            {
                MessageBox.Show("Task was unable to be deleted");
            }
        }

        private void sortButton_Click(object sender, EventArgs e)
        {
            if (sortOptions.SelectedItem == null)
            {
                MessageBox.Show("Please select an option first!");
                return;
            }

            string sortBy = sortOptions.SelectedItem.ToString();

            switch (sortBy)
            {
                case "Task Name":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(1, "Task Name");
                    break;
                case "Due Date":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(3, "Due Date");
                    break;
                case "Priority":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(4, "Priority");
                    break;
                case "Task ID":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(0, "Task ID");
                    break;
                case "User ID":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(5, "User ID");
                    break;
            }

            taskListView.Sort();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            br.Close();
            bw.Close();
            client.Close();

            base.OnFormClosing(e);
        }

        private void newClientButton_Click(object sender, EventArgs e)
        {
            try
            {
                TcpClient newClient = new TcpClient("localhost", 2050);
                NetworkStream newStream = newClient.GetStream();
                BinaryReader newBr = new BinaryReader(newStream);
                BinaryWriter newBw = new BinaryWriter(newStream);

                UserRegistrationDTO newUser = new UserRegistrationDTO { UserName = "NewUser" + new Random().Next(1000) };
                RequestDTO registerRequest = new RequestDTO { Action = "RegisterUser", Data = newUser };
                string registerRequestJson = JsonSerializer.Serialize(registerRequest);
                newBw.Write(registerRequestJson);
                newBw.Flush();

                string registerResponseJson = newBr.ReadString();
                ResponseDTO registerResponse = JsonSerializer.Deserialize<ResponseDTO>(registerResponseJson);

                if (registerResponse.Success)
                {
                    int newUserId = JsonSerializer.Deserialize<int>(registerResponse.Data.ToString());
                    ClientMainForm newClientForm = new ClientMainForm(newClient, newBr, newBw, newUserId);
                    newClientForm.Show();
                }
                else
                {
                    MessageBox.Show("Failed to register new user");
                    newBr.Close();
                    newBw.Close();
                    newClient.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to create new client: " + ex.Message);
            }
        }
        private void refreshButton_Click(object sender, EventArgs e)
        {
            LoadTasks();
        }
        private void SendRequest(RequestDTO request, out string responseJson)
        {
            SendRequest(request, bw, out responseJson);
        }

        private void SendRequest(RequestDTO request, BinaryWriter writer, out string responseJson)
        {
            var requestJson = JsonSerializer.Serialize(request);
            writer.Write(requestJson);
            writer.Flush();
            responseJson = br.ReadString();
        }
    }
}
