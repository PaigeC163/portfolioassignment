using System;
using System.IO;
using System.Net.Sockets;
using System.Text.Json;
using System.Windows.Forms;
using DTOLibrary;

namespace ClientUserRegister
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private BinaryReader br;
        private BinaryWriter bw;


        public Form1()
        {
            InitializeComponent();

        }

        private void connectButton_Click(object sender, EventArgs e)
        {
            string userName = userNameBox.Text.Trim();

            if (string.IsNullOrEmpty(userName))
            {
                MessageBox.Show("Please enter a username before clicking the CONNECT button!");
                return;
            }

            try
            {
                client = new TcpClient("127.0.0.1", 2050);
                NetworkStream stream = client.GetStream();
                br = new BinaryReader(stream);
                bw = new BinaryWriter(stream);
                RegisterUser(userName);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to connect to server: {ex.Message}");
            }
        }

        private void RegisterUser(string userName)
        {
            UserRegistrationDTO user = new UserRegistrationDTO { UserName = userName };
            RequestDTO request = new RequestDTO { Action = "RegisterUser", Data = user };
            string requestJson = JsonSerializer.Serialize(request);
            bw.Write(requestJson);
            bw.Flush();
            string responseJson = br.ReadString();
            ResponseDTO response = JsonSerializer.Deserialize<ResponseDTO>(responseJson);
            if (response.Success)
            {
                int userId = response.Data != null ? int.Parse(response.Data.ToString()) : 0;
                ClientMainForm mainForm = new ClientMainForm(client, br, bw, userId);
                mainForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("User registration failed, please try again!");
            }
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            br?.Close();
            bw?.Close();
            client?.Close();
            base.OnFormClosing(e);
        }

        private void infoBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
