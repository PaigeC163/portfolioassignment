﻿namespace ClientUserRegister
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            userNameBox = new TextBox();
            connectButton = new Button();
            infoBox1 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(62, 202);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(0, 30);
            label1.TabIndex = 0;
            // 
            // userNameBox
            // 
            userNameBox.Location = new Point(241, 228);
            userNameBox.Name = "userNameBox";
            userNameBox.PlaceholderText = "Enter Name";
            userNameBox.Size = new Size(173, 36);
            userNameBox.TabIndex = 2;
            // 
            // connectButton
            // 
            connectButton.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            connectButton.Location = new Point(265, 291);
            connectButton.Name = "connectButton";
            connectButton.Size = new Size(127, 40);
            connectButton.TabIndex = 3;
            connectButton.Text = "CONNECT";
            connectButton.UseVisualStyleBackColor = true;
            connectButton.Click += connectButton_Click;
            // 
            // infoBox1
            // 
            infoBox1.BackColor = Color.FromArgb(204, 221, 255);
            infoBox1.BorderStyle = BorderStyle.None;
            infoBox1.Enabled = false;
            infoBox1.ForeColor = Color.Black;
            infoBox1.HideSelection = false;
            infoBox1.Location = new Point(94, 69);
            infoBox1.Multiline = true;
            infoBox1.Name = "infoBox1";
            infoBox1.Size = new Size(489, 125);
            infoBox1.TabIndex = 1;
            infoBox1.Text = "Welcome to TODO, the application that allows multiple users to keep track of  tasks that need to be done. To join, just type your username below and click the \"CONNECT\" button";
            infoBox1.TextAlign = HorizontalAlignment.Center;
            infoBox1.TextChanged += infoBox1_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(12F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(204, 221, 255);
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(659, 431);
            Controls.Add(connectButton);
            Controls.Add(userNameBox);
            Controls.Add(infoBox1);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 16F);
            ForeColor = Color.Black;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(5, 6, 5, 6);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            TransparencyKey = SystemColors.WindowText;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox userNameBox;
        private Button connectButton;
        private TextBox infoBox1;
    }
}
