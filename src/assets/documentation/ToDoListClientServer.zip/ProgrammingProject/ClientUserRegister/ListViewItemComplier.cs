﻿using System;
using System.Collections;
using System.Globalization;
using System.Windows.Forms;

namespace ClientUserRegister
{
    public class ListViewItemComparer : IComparer
    {
        private int column;
        private string sortBy;

        public ListViewItemComparer(int column, string sortBy)
        {
            this.column = column;
            this.sortBy = sortBy;
        }

        public int Compare(object x, object y)
        {
            ListViewItem item1 = (ListViewItem)x;
            ListViewItem item2 = (ListViewItem)y;

            string text1 = item1.SubItems[column].Text;
            string text2 = item2.SubItems[column].Text;

            switch (sortBy)
            {
                case "Task Name":
                    return string.Compare(text1, text2);
                case "Due Date":
                    return CompareDates(text1, text2);
                case "Priority":
                    int priorityComparison = ComparePriority(item1, item2);
                    if (priorityComparison == 0)
                    {
                        return CompareDates(item1.SubItems[3].Text, item2.SubItems[3].Text);
                    }
                    return priorityComparison;
                case "Task ID":
                    return int.Parse(text1).CompareTo(int.Parse(text2));
                case "User ID":
                    return int.Parse(text1).CompareTo(int.Parse(text2));
                default:
                    return string.Compare(text1, text2);
            }
        }

        private int CompareDates(string date1, string date2)
        {
            DateTime dt1, dt2;
            bool isValidDate1 = DateTime.TryParseExact(date1, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt1);
            bool isValidDate2 = DateTime.TryParseExact(date2, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt2);

            if (isValidDate1 && isValidDate2)
            {
                return DateTime.Compare(dt1, dt2);
            }
            else if (isValidDate1)
            {
                return 1;
            }
            else if (isValidDate2)
            {
                return -1;
            }
            else
            {
                return string.Compare(date1, date2); 
            }
        }

        private int ComparePriority(ListViewItem item1, ListViewItem item2)
        {
            string priority1 = item1.SubItems[4].Text;
            string priority2 = item2.SubItems[4].Text;

            int p1 = GetPriorityValue(priority1);
            int p2 = GetPriorityValue(priority2);

            return p1.CompareTo(p2);
        }

        private int GetPriorityValue(string priority)
        {
            switch (priority.ToLower())
            {
                case "high":
                    return 1;
                case "normal":
                    return 2;
                case "low":
                    return 3;
                default:
                    return 4;
            }
        }
    }
}
