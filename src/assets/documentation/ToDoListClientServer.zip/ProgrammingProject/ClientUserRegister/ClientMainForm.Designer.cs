﻿using System.DirectoryServices;

namespace ClientUserRegister
{
    partial class ClientMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            taskListView = new ListView();
            addButton = new Button();
            deleteButton = new Button();
            sortButton = new Button();
            sortOptions = new ComboBox();
            label1 = new Label();
            newClientButton = new Button();
            refreshButton = new Button();
            SuspendLayout();
            // 
            // taskListView
            // 
            taskListView.Font = new Font("Segoe UI", 12F);
            taskListView.FullRowSelect = true;
            taskListView.GridLines = true;
            taskListView.Location = new Point(12, 113);
            taskListView.Name = "taskListView";
            taskListView.Size = new Size(753, 307);
            taskListView.TabIndex = 0;
            taskListView.UseCompatibleStateImageBehavior = false;
            taskListView.View = View.Details;
            // 
            // addButton
            // 
            addButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addButton.Location = new Point(608, 455);
            addButton.Name = "addButton";
            addButton.Size = new Size(128, 31);
            addButton.TabIndex = 1;
            addButton.Text = "ADD NEW TASK";
            addButton.UseVisualStyleBackColor = true;
            addButton.Click += addButton_Click;
            // 
            // deleteButton
            // 
            deleteButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deleteButton.Location = new Point(30, 455);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(170, 31);
            deleteButton.TabIndex = 2;
            deleteButton.Text = "DELETE TASK/TASKS";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click;
            // 
            // sortButton
            // 
            sortButton.Font = new Font("Segoe UI", 12F);
            sortButton.Location = new Point(647, 68);
            sortButton.Name = "sortButton";
            sortButton.Size = new Size(118, 36);
            sortButton.TabIndex = 3;
            sortButton.Text = "SORT BY";
            sortButton.UseVisualStyleBackColor = true;
            sortButton.Click += sortButton_Click;
            // 
            // sortOptions
            // 
            sortOptions.Font = new Font("Segoe UI", 12F);
            sortOptions.FormattingEnabled = true;
            sortOptions.Items.AddRange(new object[] { "Task Name", "Due Date", "Priority", "Task ID", "User ID" });
            sortOptions.Location = new Point(520, 73);
            sortOptions.Name = "sortOptions";
            sortOptions.Size = new Size(121, 29);
            sortOptions.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(30, 35);
            label1.Name = "label1";
            label1.Size = new Size(136, 37);
            label1.TabIndex = 5;
            label1.Text = "To Do List";
            // 
            // newClientButton
            // 
            newClientButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            newClientButton.Location = new Point(608, 517);
            newClientButton.Name = "newClientButton";
            newClientButton.Size = new Size(128, 31);
            newClientButton.TabIndex = 6;
            newClientButton.Text = "ADD FRIEND";
            newClientButton.UseVisualStyleBackColor = true;
            newClientButton.Click += newClientButton_Click;
            // 
            // refreshButton
            // 
            refreshButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            refreshButton.Location = new Point(30, 517);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(101, 31);
            refreshButton.TabIndex = 7;
            refreshButton.Text = "REFRESH";
            refreshButton.UseVisualStyleBackColor = true;
            refreshButton.Click += refreshButton_Click;
            // 
            // ClientMainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(204, 221, 255);
            ClientSize = new Size(777, 592);
            Controls.Add(refreshButton);
            Controls.Add(newClientButton);
            Controls.Add(label1);
            Controls.Add(sortOptions);
            Controls.Add(sortButton);
            Controls.Add(deleteButton);
            Controls.Add(addButton);
            Controls.Add(taskListView);
            Name = "ClientMainForm";
            StartPosition = FormStartPosition.Manual;
            Text = "ClientMainForm";
            Load += ClientMainForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView taskListView;
        private Button addButton;
        private Button deleteButton;
        private Button sortButton;
        private ComboBox sortOptions;
        private Label label1;
        private Button newClientButton;
        private Button refreshButton;
    }
}