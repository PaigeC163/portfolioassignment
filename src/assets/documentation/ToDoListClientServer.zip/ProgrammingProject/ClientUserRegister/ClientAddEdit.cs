﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading;
using System.Data.SQLite;
using DTOLibrary;
namespace ClientUserRegister
{
    public partial class ClientAddEdit : Form
    {
        private BinaryReader br;
        private BinaryWriter bw;
        private int userId;
        private bool isEditMode;
        private int taskId;

        public ClientAddEdit(BinaryReader br, BinaryWriter bw, int userId)
        {
            InitializeComponent();
            this.br = br;
            this.bw = bw;
            this.userId = userId;
            userIDBox.Text = userId.ToString();
            userIDBox.Enabled = false;
            isEditMode = false;
            label6.Text = "Add a Task";
        }

        
        public ClientAddEdit(BinaryReader br, BinaryWriter bw, ToDoItemDTO task)
        {
            InitializeComponent();
            this.br = br;
            this.bw = bw;
            this.userId = task.UserID;
            this.taskId = task.TaskID;
            userIDBox.Text = userId.ToString();
            userIDBox.Enabled = false;
            taskNameBox.Text = task.TaskName;
            taskDescriptionBox.Text = task.Description;
            dueDateBox.Text = task.DueDate;
            priorityOptionsBox.SelectedItem = task.Priority;
            isEditMode = true;
            label6.Text = "Edit a Task";
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(taskNameBox.Text) || string.IsNullOrEmpty(taskDescriptionBox.Text) ||
               string.IsNullOrEmpty(dueDateBox.Text) || priorityOptionsBox.SelectedItem == null)
            {
                MessageBox.Show("Please fill in all fields!");
                return;
            }

            ToDoItemDTO task = new ToDoItemDTO
            {
                TaskName = taskNameBox.Text,
                Description = taskDescriptionBox.Text,
                DueDate = dueDateBox.Text,
                Priority = priorityOptionsBox.SelectedItem.ToString(),
                UserID = userId,
                TaskID = isEditMode ? taskId : 0
            };

            string action = isEditMode ? "EditTask" : "AddTask";
            RequestDTO request = new RequestDTO { Action = action, Data = task };
            string requestJson = JsonSerializer.Serialize(request);
            bw.Write(requestJson);
            bw.Flush();
            string responseJson = br.ReadString();
            ResponseDTO response = JsonSerializer.Deserialize<ResponseDTO>(responseJson);

            if (response.Success)
            {
                this.Close();
            }
            else
            {
                MessageBox.Show($"Task wasn't {(isEditMode ? "edited" : "added")}!");
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
