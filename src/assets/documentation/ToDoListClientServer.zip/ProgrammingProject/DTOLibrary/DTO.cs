﻿using System;

namespace DTOLibrary
{
    public class UserDTO
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
    }

    public class ToDoItemDTO
    {
        public int TaskID { get; set; }
        public string TaskName { get; set; }
        public string Description { get; set; }
        public string DueDate { get; set; }
        public string Priority { get; set; }
        public int UserID { get; set; }
    }

    public class RequestDTO
    {
        public string Action { get; set; }
        public object Data { get; set; }
    }

    public class ResponseDTO
    {
        public bool Success { get; set; }
        public object Data { get; set; }
    }

    public class UserRegistrationDTO
    {
        public string UserName { get; set; }
    }
}

