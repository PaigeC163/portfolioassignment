﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading;
using DTOLibrary;
using System.Data.SQLite;

namespace Server
{
    internal class Program
    {
        private static TcpListener listener;
        private static Dictionary<int, TcpClient> clients = new Dictionary<int, TcpClient>();
        private static Dictionary<int, string> clientUsernames = new Dictionary<int, string>();
        private static int clientIDCounter = 1;
        private static string CSTRING = @"Data Source=toDoList.db;Version=3";

        static void Main(string[] args)
        {
            listener = new TcpListener(IPAddress.Any, 2050);
            listener.Start();

            Console.WriteLine("Server started on port 2050");

            Thread listenThread = new Thread(ListenForClients);
            listenThread.Start();
        }

        public static void ListenForClients()
        {
            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                int clientId = clientIDCounter++;

                lock (clients)
                {
                    clients.Add(clientId, client);
                }

                Console.WriteLine("Client " + clientId + " connected");

                Thread clientThread = new Thread(() => HandleClientComm(client, clientId));
                clientThread.Start();
            }
        }

        private static void HandleClientComm(TcpClient client, int clientId)
        {
            using (NetworkStream stream = client.GetStream())
            using (BinaryReader br = new BinaryReader(stream))
            using (BinaryWriter bw = new BinaryWriter(stream))
            {
                while (true)
                {
                    try
                    {
                        string requestJson = br.ReadString();
                        RequestDTO request = JsonSerializer.Deserialize<RequestDTO>(requestJson);
                        if (request != null)
                        {
                            ResponseDTO response = ProcessRequest(request, clientId);
                            SendResponse(bw, response);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Client {clientId} disconnected. See you next time!");
                        lock (clients)
                        {
                            clients.Remove(clientId);
                            clientUsernames.Remove(clientId);
                        }
                        break;
                    }
                }
            }
        }

        private static ResponseDTO ProcessRequest(RequestDTO request, int clientId)
        {
            ResponseDTO response;

            switch (request.Action)
            {
                case "AddTask":
                    response = AddTask(request.Data, clientId);
                    break;
                case "DeleteTask":
                    response = DeleteTask(request.Data, clientId);
                    break;
                case "EditTask":
                    response = EditTask(request.Data, clientId);
                    break;
                case "GetTasks":
                    response = GetTasks();
                    break;
                case "RegisterUser":
                    response = RegisterUser(request.Data, clientId);
                    break;
                default:
                    response = new ResponseDTO
                    {
                        Success = false
                    };
                    break;
            }
            return response;
        }

        private static void SendResponse(BinaryWriter bw, ResponseDTO response)
        {
            string responseJson = JsonSerializer.Serialize(response);
            bw.Write(responseJson);
            bw.Flush();
        }

        private static ResponseDTO RegisterUser(object data, int clientId)
        {
            UserRegistrationDTO newUser = JsonSerializer.Deserialize<UserRegistrationDTO>(data.ToString());
            int userId = -1;
            bool isNewUser = false;

            using (SQLiteConnection conn = new SQLiteConnection(CSTRING))
            {
                conn.Open();
                string sql = "SELECT UserID FROM Users WHERE UserName = @UserName";
                using (SQLiteCommand selectCommand = new SQLiteCommand(sql, conn))
                {
                    selectCommand.Parameters.AddWithValue("@UserName", newUser.UserName);
                    object result = selectCommand.ExecuteScalar();
                    if (result != null)
                    {
                        userId = Convert.ToInt32(result);
                    }
                }

               
                if (userId == -1)
                {
                    isNewUser = true;
                    sql = "INSERT INTO Users (UserName) VALUES (@UserName); SELECT last_insert_rowid()";
                    using (SQLiteCommand insertCommand = new SQLiteCommand(sql, conn))
                    {
                        insertCommand.Parameters.AddWithValue("@UserName", newUser.UserName);
                        userId = Convert.ToInt32(insertCommand.ExecuteScalar());
                    }
                }
            }

            lock (clientUsernames)
            {
                clientUsernames[clientId] = newUser.UserName;
            }

            string welcomeMessage = isNewUser ? "Welcome to the To Do List!" : "Welcome Back to the To Do List!";
            Console.WriteLine($"User {newUser.UserName} (Client {clientId}) {welcomeMessage}");

            return new ResponseDTO
            {
                Success = true,
                Data = userId
            };
        }



        private static ResponseDTO AddTask(object data, int clientId)
        {
            ToDoItemDTO task = JsonSerializer.Deserialize<ToDoItemDTO>(data.ToString());
            using (SQLiteConnection conn = new SQLiteConnection(CSTRING))
            {
                conn.Open();
                string sql = "INSERT INTO toDo (taskName, description, dueDate, priority, userID) VALUES (@taskName, @description, @dueDate, @priority, @userID)";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskName", task.TaskName);
                    cmd.Parameters.AddWithValue("@description", task.Description);
                    cmd.Parameters.AddWithValue("@dueDate", task.DueDate);
                    cmd.Parameters.AddWithValue("@priority", task.Priority);
                    cmd.Parameters.AddWithValue("@userID", task.UserID);
                    cmd.ExecuteNonQuery();
                }
            }

            string username = clientUsernames.ContainsKey(clientId) ? clientUsernames[clientId] : "Unknown";
            Console.WriteLine($"User {username} (Client {clientId}) added a task called {task.TaskName}. Task ID is {task.TaskID}. Refresh the list.");

            return new ResponseDTO
            {
                Success = true
            };
        }

        private static ResponseDTO DeleteTask(object data, int clientId)
        {
            int taskId = JsonSerializer.Deserialize<int>(data.ToString());
            using (SQLiteConnection conn = new SQLiteConnection(CSTRING))
            {
                conn.Open();
                string sql = "DELETE FROM toDo WHERE taskID = @taskID";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskID", taskId);
                    cmd.ExecuteNonQuery();
                }
            }

            string username = clientUsernames.ContainsKey(clientId) ? clientUsernames[clientId] : "Unknown";
            Console.WriteLine($"User {username} (Client {clientId}) deleted a task with the Task ID {taskId}. Refresh the list.");

            return new ResponseDTO
            {
                Success = true
            };
        }

        private static ResponseDTO EditTask(object data, int clientId)
        {
            ToDoItemDTO task = JsonSerializer.Deserialize<ToDoItemDTO>(data.ToString());
            using (SQLiteConnection conn = new SQLiteConnection(CSTRING))
            {
                conn.Open();
                string sql = "UPDATE toDo SET taskName = @taskName, description = @description, dueDate = @dueDate, priority = @priority WHERE taskID = @taskID";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@taskName", task.TaskName);
                    cmd.Parameters.AddWithValue("@description", task.Description);
                    cmd.Parameters.AddWithValue("@dueDate", task.DueDate);
                    cmd.Parameters.AddWithValue("@priority", task.Priority);
                    cmd.Parameters.AddWithValue("@taskID", task.TaskID);
                    cmd.ExecuteNonQuery();
                }
            }

            string username = clientUsernames.ContainsKey(clientId) ? clientUsernames[clientId] : "Unknown";
            Console.WriteLine($"User {username} (Client {clientId}) edited a task called {task.TaskName}. Task ID of {task.TaskID}. Refresh the list.");

            return new ResponseDTO
            {
                Success = true
            };
        }

        private static ResponseDTO GetTasks()
        {
            List<ToDoItemDTO> tasks = new List<ToDoItemDTO>();
            using (SQLiteConnection conn = new SQLiteConnection(CSTRING))
            {
                conn.Open();
                string sql = "SELECT * FROM toDo";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    using (SQLiteDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            tasks.Add(new ToDoItemDTO
                            {
                                TaskID = rdr.GetInt32(0),
                                TaskName = rdr.GetString(1),
                                Description = rdr.GetString(2),
                                DueDate = rdr.GetString(3),
                                Priority = rdr.GetString(4),
                                UserID = rdr.GetInt32(5)
                            });
                        }
                    }
                }
            }
            return new ResponseDTO
            {
                Success = true,
                Data = tasks
            };
        }
    }
}
