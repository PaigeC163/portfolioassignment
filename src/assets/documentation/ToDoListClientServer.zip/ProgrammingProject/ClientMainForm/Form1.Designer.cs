﻿namespace ClientMainForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            taskListView = new ListView();
            addButton = new Button();
            deleteButton = new Button();
            sortButton = new Button();
            sortOptions = new ComboBox();
            SuspendLayout();
            // 
            // taskListView
            // 
            taskListView.Location = new Point(12, 54);
            taskListView.Name = "taskListView";
            taskListView.Size = new Size(574, 292);
            taskListView.TabIndex = 0;
            taskListView.Columns.Add("Task ID", 50);
            taskListView.Columns.Add("Task Name", 150);
            taskListView.Columns.Add("Description", 200);
            taskListView.Columns.Add("Due Date", 100);
            taskListView.Columns.Add("Priority", 100);
            taskListView.Columns.Add("User Id", 100);
            taskListView.UseCompatibleStateImageBehavior = false;
            // 
            // addButton
            // 
            addButton.Font = new Font("Segoe UI", 16F);
            addButton.Location = new Point(12, 367);
            addButton.Name = "addButton";
            addButton.Size = new Size(143, 71);
            addButton.TabIndex = 1;
            addButton.Text = "ADD NEW TASK";
            addButton.UseVisualStyleBackColor = true;
            addButton.Click += addButton_Click;
            // 
            // deleteButton
            // 
            deleteButton.Font = new Font("Segoe UI", 16F);
            deleteButton.Location = new Point(433, 367);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(153, 71);
            deleteButton.TabIndex = 2;
            deleteButton.Text = "DELETE TASK/TASKS";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click;
            // 
            // sortButton
            // 
            sortButton.Font = new Font("Segoe UI", 12F);
            sortButton.Location = new Point(12, 12);
            sortButton.Name = "sortButton";
            sortButton.Size = new Size(118, 36);
            sortButton.TabIndex = 3;
            sortButton.Text = "SORT BY";
            sortButton.UseVisualStyleBackColor = true;
            sortButton.Click += sortButton_Click;
            // 
            // sortOptions
            // 
            sortOptions.Font = new Font("Segoe UI", 12F);
            sortOptions.FormattingEnabled = true;
            sortOptions.Items.AddRange(new object[] { "Task Name", "Due Date", "Priority", "Task ID", "User ID" });
            sortOptions.Location = new Point(135, 16);
            sortOptions.Name = "sortOptions";
            sortOptions.Size = new Size(121, 29);
            sortOptions.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(sortOptions);
            Controls.Add(sortButton);
            Controls.Add(deleteButton);
            Controls.Add(addButton);
            Controls.Add(taskListView);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private ListView taskListView;
        private Button addButton;
        private Button deleteButton;
        private Button sortButton;
        private ComboBox sortOptions;
    }
}
