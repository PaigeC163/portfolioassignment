using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading;
using DTOLibrary;
using System.Data.SQLite;
namespace ClientMainForm
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private BinaryReader br;
        private BinaryWriter bw;

        public Form1(TcpClient client, BinaryReader br, BinaryWriter bw)
        {
            InitializeComponent();
            this.client = client;
            this.br = br;
            this.bw = bw;

            LoadTasks();
        }

        private void LoadTasks()
        {
            RequestDTO request = new RequestDTO { Action = "GetTasks" };
            string requestJson = JsonSerializer.Serialize(request);
            bw.Write(requestJson);
            bw.Flush();

            string responseJson = br.ReadString();
            ResponseDTO response = JsonSerializer.Deserialize<ResponseDTO>(responseJson);
            if (response.Success)
            {
                List<ToDoItemDTO> tasks = JsonSerializer.Deserialize<List<ToDoItemDTO>>(response.Data.ToString());
                foreach (var item in tasks)
                {
                    var listViewItem = new ListViewItem(item.TaskID.ToString());
                    listViewItem.SubItems.Add(item.TaskName.ToString());
                    listViewItem.SubItems.Add(item.Description.ToString());
                    listViewItem.SubItems.Add(item.DueDate.ToString());
                    listViewItem.SubItems.Add(item.Priority.ToString());
                    listViewItem.SubItems.Add(item.UserID.ToString());
                    taskListView.Items.Add(listViewItem);
                }
            }
            else
            {
                MessageBox.Show("Was unable to show tasks");
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            ClientAddTaskForm addTaskForm = new ClientAddTaskForm(bw, br);
            addTaskForm.ShowDialog();
            LoadTasks();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (taskListView.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select an item to delete first!");
                return;
            }

            int taskId = int.Parse(taskListView.SelectedItems[0].Text);
            RequestDTO request = new RequestDTO { Action = "DeleteTask", Data = taskId };
            string requestJson = JsonSerializer.Serialize(request);
            bw.Write(requestJson);
            bw.Flush();
            string responseJson = br.ReadString();
            ResponseDTO response = JsonSerializer.Deserialize<ResponseDTO>(responseJson);

            if (response.Success)
            {
                LoadTasks();
            }
            else
            {
                MessageBox.Show("Task was unable to be deleted");
            }
        }

        private void sortButton_Click(object sender, EventArgs e)
        {
            if (sortOptions.SelectedItem == null)
            {
                MessageBox.Show("Please select an option first!");
                return;
            }

            string sortBy = sortOptions.SelectedItem.ToString();

            switch (sortBy)
            {
                case "Task Name":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(1, "Task Name");
                    break;
                case "Due Date":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(3, "Due Date");
                    break;
                case "Priority":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(4, "Priority");
                    break;
                case "Task ID":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(0, "Task ID");
                    break;
                case "User ID":
                    taskListView.ListViewItemSorter = new ListViewItemComparer(5, "User ID");
                    break;
            }

            taskListView.Sort();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            br.Close();
            bw.Close();
            client.Close();

            base.OnFormClosing(e);
        }
    }


}
