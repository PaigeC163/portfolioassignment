import pygame
import time
import random

Little_Hero = pygame.image.load('herospr2.png')
Basilisk_Body_X_negX = pygame.image.load('Basilisk_Body_X_-X.png')
Basilisk_Body_negX_X = pygame.image.load('Basilisk_Body_-X_X.png')
Basilisk_Body_Y_negY = pygame.image.load('Basilisk_Body_Y_-Y.png')
Basilisk_Body_negY_Y = pygame.image.load('Basilisk_Body_-Y_Y.png')
Basilisk_Tail_X_negX = pygame.image.load('Basilisk_Tail_X_-X.png')
Basilisk_Tail_negX_X = pygame.image.load('Basilisk_Tail_-X_X.png')
Basilisk_Tail_Y_negY = pygame.image.load('Basilisk_Tail_Y_-Y.png')
Basilisk_Tail_negY_Y = pygame.image.load('Basilisk_Tail_-Y_Y.png')
Basilisk_Head_X_negX = pygame.image.load('Basilisk_Head_X_-X.png')
Basilisk_Head_negX_X = pygame.image.load('Basilisk_Head_-X_X.png')
Basilisk_Head_Y_negY = pygame.image.load('Basilisk_Head_Y_-Y.png')
Basilisk_Head_negY_Y = pygame.image.load('Basilisk_Head_-Y_Y.png')
Basilisk_Curve_Body_X_Y = pygame.image.load('Snake_Curve_Body_X_Y.png')
Basilisk_Curve_Body_negX_negY = pygame.image.load('Snake_Curve_Body_-X_-Y.png')
Basilisk_Curve_Body_X_negY = pygame.image.load('Snake_Curve_Body_X_-Y.png')
Basilisk_Curve_Body_negX_Y = pygame.image.load('Snake_Curve_Body_-X_Y.png')
Basilisk_Curve_Body_Y_X = pygame.image.load('Snake_Curve_Body_Y_X.png')
Basilisk_Curve_Body_negY_negX = pygame.image.load('Snake_Curve_Body_-Y_-X.png')
Basilisk_Curve_Body_Y_negX = pygame.image.load('Snake_Curve_Body_Y_-X.png')
Basilisk_Curve_Body_negY_X = pygame.image.load('Snake_Curve_Body_-Y_X.png')
Basilisk_Egg = pygame.image.load('Basilisk_Egg.png')


pygame.init()

white = (255, 255, 255)
green = (128, 186, 93)
black = (0, 0, 0)
red = (213, 50, 80)
blue = (50, 153, 213)

dis_width = 600
dis_height = 400

dis = pygame.display.set_mode((dis_width, dis_height))
pygame.display.set_caption('Basilisk VS Little Hero')

clock = pygame.time.Clock()

snake_block = 40
snake_speed = 5

font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)

def your_score(score):
  value = score_font.render("Your Score: " + str(score), True, black)
  dis.blit(value, [0, 0])

def our_snake(snake_block, snake_list):
  if len(snake_list) == 1:
    dis.blit(Basilisk_Egg , (snake_list[0][0], snake_list[0][1]))
  elif len(snake_list) == 2:
    if snake_list[0][0]>snake_list[1][0]:
      dis.blit(Basilisk_Tail_X_negX , (snake_list[0][0], snake_list[0][1]))
    elif snake_list[0][0]<snake_list[1][0]:
      dis.blit(Basilisk_Tail_negX_X , (snake_list[0][0], snake_list[0][1]))
    elif snake_list[0][1]>snake_list[1][1]:
      dis.blit(Basilisk_Tail_negY_Y , (snake_list[0][0], snake_list[0][1]))
    elif snake_list[0][1]<snake_list[1][1]:
      dis.blit(Basilisk_Tail_Y_negY , (snake_list[0][0], snake_list[0][1]))



    
    if snake_list[-1][0]>snake_list[-2][0]:
      dis.blit(Basilisk_Head_negX_X , (snake_list[-1][0], snake_list[-1][1]))
    elif snake_list[-1][0]<snake_list[-2][0]:
      dis.blit(Basilisk_Head_X_negX , (snake_list[-1][0], snake_list[-1][1]))
    elif snake_list[-1][1]>snake_list[-2][1]:
      dis.blit(Basilisk_Head_Y_negY , (snake_list[-1][0], snake_list[-1][1]))
    elif snake_list[-1][1]<snake_list[-2][1]:
      dis.blit(Basilisk_Head_negY_Y , (snake_list[-1][0], snake_list[-1][1]))


    
  else:
    

    if snake_list[0][0]>snake_list[1][0]:
      dis.blit(Basilisk_Tail_X_negX , (snake_list[0][0], snake_list[0][1]))
    elif snake_list[0][0]<snake_list[1][0]:
      dis.blit(Basilisk_Tail_negX_X , (snake_list[0][0], snake_list[0][1]))
    elif snake_list[0][1]>snake_list[1][1]:
      dis.blit(Basilisk_Tail_negY_Y , (snake_list[0][0], snake_list[0][1]))
    elif snake_list[0][1]<snake_list[1][1]:
      dis.blit(Basilisk_Tail_Y_negY , (snake_list[0][0], snake_list[0][1]))
      
    for i in range(1, len(snake_list)-1):
      if snake_list[i][0] == snake_list[i-1][0] and snake_list[i][0] == snake_list[i+1][0]:
        if snake_list[i-1][1] < snake_list[i+1][1]:
          dis.blit(Basilisk_Body_Y_negY , (snake_list[i][0], snake_list[i][1]))
        else:
          dis.blit(Basilisk_Body_negY_Y , (snake_list[i][0], snake_list[i][1]))
          
      if snake_list[i][1] == snake_list[i-1][1] and snake_list[i][1] == snake_list[i+1][1]:
        if snake_list[i-1][0] < snake_list[i+1][0]:
          dis.blit(Basilisk_Body_negX_X , (snake_list[i][0], snake_list[i][1]))
        else:
          dis.blit(Basilisk_Body_X_negX , (snake_list[i][0], snake_list[i][1]))

      if snake_list[i][1] == snake_list[i-1][1] and snake_list[i][1] == snake_list[i+1][1]:
        if snake_list[i-1][0] < snake_list[i+1][0]:
          dis.blit(Basilisk_Body_negX_X , (snake_list[i][0], snake_list[i][1]))
        else:
          dis.blit(Basilisk_Body_X_negX , (snake_list[i][0], snake_list[i][1]))


      if snake_list[i][0] <= snake_list[i-1][0] and snake_list[i][0] <= snake_list[i+1][0]:
        if snake_list[i][1] >= snake_list[i-1][1] and snake_list[i][1] >= snake_list[i+1][1]:
          if snake_list[i-1][1] < snake_list[i+1][1]:
            dis.blit(Basilisk_Curve_Body_Y_X , (snake_list[i][0], snake_list[i][1]))
          else:
            dis.blit(Basilisk_Curve_Body_X_Y , (snake_list[i][0], snake_list[i][1]))
      
      if snake_list[i][0] <= snake_list[i-1][0] and snake_list[i][0] <= snake_list[i+1][0]:
        if snake_list[i][1] <= snake_list[i-1][1] and snake_list[i][1] <= snake_list[i+1][1]:
          if snake_list[i-1][1] < snake_list[i+1][1]:
            dis.blit(Basilisk_Curve_Body_X_negY , (snake_list[i][0], snake_list[i][1]))
          else:
            dis.blit(Basilisk_Curve_Body_negY_X , (snake_list[i][0], snake_list[i][1]))

      if snake_list[i][0] >= snake_list[i-1][0] and snake_list[i][0] >= snake_list[i+1][0]:
        if snake_list[i][1] >= snake_list[i-1][1] and snake_list[i][1] >= snake_list[i+1][1]:
          if snake_list[i-1][1] < snake_list[i+1][1]:
            dis.blit(Basilisk_Curve_Body_Y_negX , (snake_list[i][0], snake_list[i][1]))
          else:
            dis.blit(Basilisk_Curve_Body_negX_Y , (snake_list[i][0], snake_list[i][1]))

      if snake_list[i][0] >= snake_list[i-1][0] and snake_list[i][0] >= snake_list[i+1][0]:
        if snake_list[i][1] <= snake_list[i-1][1] and snake_list[i][1] <= snake_list[i+1][1]:
          if snake_list[i-1][1] < snake_list[i+1][1]:
            dis.blit(Basilisk_Curve_Body_negX_negY , (snake_list[i][0], snake_list[i][1]))
          else:
            dis.blit(Basilisk_Curve_Body_negY_negX , (snake_list[i][0], snake_list[i][1]))
          
    if snake_list[-1][0]>snake_list[-2][0]:
      dis.blit(Basilisk_Head_negX_X , (snake_list[-1][0], snake_list[-1][1]))
    elif snake_list[-1][0]<snake_list[-2][0]:
      dis.blit(Basilisk_Head_X_negX , (snake_list[-1][0], snake_list[-1][1]))
    elif snake_list[-1][1]>snake_list[-2][1]:
      dis.blit(Basilisk_Head_Y_negY , (snake_list[-1][0], snake_list[-1][1]))
    elif snake_list[-1][1]<snake_list[-2][1]:
      dis.blit(Basilisk_Head_negY_Y , (snake_list[-1][0], snake_list[-1][1]))

      



def message(msg, color):
  mesg = font_style.render(msg, True, color)
  dis.blit(mesg, [dis_width / 6, dis_height / 3])


def gameLoop(): 


  game_over = False
  game_close = False

  x1 = 40
  y1 = 40

  x1_change = 0
  y1_change = 0

  snake_list = []
  length_of_snake = 1

  foodx = round(random.randrange(0, dis_width - snake_block) / snake_block) * snake_block
  foody = round(random.randrange(0, dis_height - snake_block) / snake_block) * snake_block

  while not game_over:

    while game_close == True:
      dis.fill(green)
      message("You Died! Press Q to Quit or C to Play Again", red)

      pygame.display.update()

      for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
          if event.key == pygame.K_q:
            game_over = True
            game_close = False
          if event.key == pygame.K_c:
            gameLoop()

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        game_over = True
      if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_LEFT or event.key == pygame.K_a:
          x1_change = -snake_block
          y1_change = 0
        elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
          x1_change = snake_block
          y1_change = 0
        elif event.key == pygame.K_UP or event.key == pygame.K_w:
          y1_change = -snake_block
          x1_change = 0
        elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
          y1_change = snake_block
          x1_change = 0

    if x1 >= dis_width or x1 < 0 or y1 >= dis_height or y1 <0:
      game_close = True
    x1 += x1_change
    y1 += y1_change
    dis.fill(green)

    dis.blit(Little_Hero, (foodx, foody))
    snake_head = []
    snake_head.append(x1)
    snake_head.append(y1)
    snake_list.append(snake_head)
    if len(snake_list) > length_of_snake:
      del snake_list[0]

    for x in snake_list[:-1]:
      if x == snake_head:
        game_close = True

    our_snake(snake_block, snake_list)
    your_score(length_of_snake - 1)
    
    pygame.display.update()

    if x1 == foodx and y1 == foody:
      foodx = round(random.randrange(0, dis_width - snake_block) / snake_block) * snake_block
      foody = round(random.randrange(0, dis_height - snake_block) / snake_block) * snake_block
      length_of_snake += 1

    clock.tick(snake_speed)

  
  pygame.quit()
  quit()

gameLoop()

